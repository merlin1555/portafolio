<nav>
    <ul class="menu_principal">
        <li id="menu_bio"><a href="#biografia">Sobre mi</a></li>
        <li id="menu_evi"><a href="#evidencias">Trabajos previos</a></li>
        <li id="menu_item"><a href="#">Item 3</a></li>
        <li id="menu_cont"><a href="#contacto">Contacto</a></li>
        <li id="modo_oscuro_btn">
            <button id="modo_claro"><i class="fa-solid fa-moon"></i></button>
            <button id="modo_oscuro"><i class="fa-solid fa-sun"></i></button>
        </li>
	</ul>
</nav>