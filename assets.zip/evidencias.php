<section id="evidencias">
    <h2 class="fade-in-section">Trabajos Previos:</h2>
    <ul class="lista_evidencias">
        <li class="fade-in-section"><span>Evidencia 1</span></li>
        <li class="fade-in-section"><span>BioPlast.cl</span></li>
        <li class="fade-in-section"><span>Aritos3D.cl</span></li>
        <li class="fade-in-section"><span>Examen Final</span></li>
        <li class="fade-in-section"><span>Blog: ¿Qué Aprendí?</span></li>
        <li class="fade-in-section"><span>Liceo Carmen Arriaran</span></li>
    </ul>
</section>