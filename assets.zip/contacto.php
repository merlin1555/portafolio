<section id="contacto">
<h2 class="fade-in-section">Contacto</h2>
    <ul class="menu_social fade-in-section">
        <li id="contacto_correo"><i class="fa-solid fa-envelope"></i><span>Correo</span></li>
        <li id="contacto_github"><i class="fa-brands fa-github"></i><span>GitHub</span></li>
        <li id="contacto_linkedin"><i class="fa-brands fa-linkedin"></i><span>Linkedin</span></li>
        <li id="contacto_discord"><i class="fa-brands fa-discord"></i><span>Discord</span></li>
    </ul>
</section>