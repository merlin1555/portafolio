<footer>
<hr>
	<!-- <p>Nicolás Orellana © <?php echo date('Y');?> - Todos los derechos reservados</p> -->
</footer>