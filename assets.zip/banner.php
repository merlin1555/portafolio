<section id="banner">
    <div class="banner_principal">
        <div class="container">
            <div class="sky">
                <div class="text" id="CODEVEMBER"></div>
                <div class="stars"></div>
                <div class="stars1"></div>
                <div class="stars2"></div>
                <div class="shooting-stars"></div>
            </div>
        </div>
    </div>
</section>
<hr style="margin: 0;">