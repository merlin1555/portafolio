
<?php include("header.php");?>


<main>
<!-- Biografia -->
<?php include("biografia.php");?>

<!-- Evidencias -->
<?php include("evidencias.php");?>

<!-- Conocimientos (Git) -->

<!-- Contacto -->
<?php include("contacto.php");?>

</main>
<!-- Footer -->
<?php include("footer.php");?>
<script src="assets/js/scripts.js"></script>
</body>
</html>